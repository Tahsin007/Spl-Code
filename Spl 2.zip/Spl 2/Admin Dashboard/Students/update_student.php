<?php
// Check if the student_id query parameter is set
if (isset($_GET["student_id"])) {
    // Database configuration
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "exam pilot"; 

    // Create a database connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get the student ID from the URL
    $studentId = $_GET["student_id"];

    // Retrieve the student's data based on the student ID
    $sql = "SELECT * FROM students WHERE student_id = '$studentId' ";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Fetch the student's data
        $row = $result->fetch_assoc();
        $studentName = $row["student_name"];
        $emailId = $row["email_id"];
        $contact = $row["contact"];
        $deptName=$row["dept_name"];
        $password=$row["password"];
        // Add other fields as needed

        // Close the database connection
        $conn->close();
    } else {
        echo "Student not found.";
        exit; // Exit the script if the student is not found
    }
} else {
    echo "Student ID not provided.";
    exit; // Exit the script if no student ID is provided
}
?>


<!DOCTYPE html>
<html>
<head>
  <title>Edit Student Details</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="container">
    <div class="content">
      <div class="title-section">
        <h1>Edit Student Details</h1>
      </div>
      <div class="form-section">
        <form method="post" action="changeStudents.php">
          <!-- <input type="text" name="student_id" value="<?php echo $studentId; ?>"> -->
          <div class="form-field">
            <label for="studentId">Student ID:</label>
            <input type="text" name="student_id" value="<?php echo $studentId; ?>">
          </div>
          <div class="form-field">
            <label for="studentName">Student Name:</label>
            <input type="text" name="student_name" value="<?php echo $studentName; ?>" required>
          </div>
          <div class="form-field">
            <label for="emailId">Email ID:</label>
            <input type="text" name="email_id" value="<?php echo $emailId; ?>" >
          </div>
          <div class="form-field">
            <label for="contact">Contact:</label>
            <input type="text" name="contact" value="<?php echo $contact; ?>" >
          </div>
          <div class="form-field">
            <label for="deptName">Dept Name:</label>
            <input type="text" name="deptName" value="<?php echo $deptName; ?>" >
          </div>
          <div class="form-field">
            <label for="password">Password :</label>
            <input type="text" name="password" value="<?php echo $password; ?>" >
          </div>
          <!-- Add other form fields as needed -->
          <div class="form-actions">
            <button type="submit">Update</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</body>
</html>
