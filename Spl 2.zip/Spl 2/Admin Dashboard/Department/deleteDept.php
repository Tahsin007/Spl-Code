<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "exam pilot";

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET["dept_code"])) {
    $dept_code = $_GET["dept_code"];

    // Delete the student record from the database
    $sql = "DELETE FROM department WHERE dept_code = '$dept_code'";

    if ($conn->query($sql) === TRUE) {
        echo "Student record deleted successfully.";
    } else {
        echo "Error deleting student record: " . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>
