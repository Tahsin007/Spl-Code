const express = require('express')
const app = express();
const path = require('path');
const bodyparser = require("body-parser");
const connectDB = require('./server/database/connection');

app.set("view engine","ejs");
app.use(express.json());
//app.use(express.static(static_path));

app.use(express.urlencoded({extended:false}));
//load assets
app.use('/css',express.static(path.resolve(__dirname,"assets/css")))
app.use('/img',express.static(path.resolve(__dirname,"assets/img")))
app.use('/js',express.static(path.resolve(__dirname,"assets/js")))

//load routers
app.use('/',require('./server/routes/router'));
app.use(bodyparser.urlencoded({ extended : true}))


connectDB();


app.listen(4000, ()=>{ console.log(`Server is connected to the ${4000} port`)});