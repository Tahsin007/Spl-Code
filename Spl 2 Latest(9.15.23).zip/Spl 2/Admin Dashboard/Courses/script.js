// Toggle menu on mobile devices
var menuIcon = document.querySelector('.menu-icon');
var menuItems = document.querySelector('.menu-items');
menuIcon.addEventListener('click', function() {
  menuItems.classList.toggle('active');
});

// Form submit event listener
var courseForm = document.getElementById('courseForm');
courseForm.addEventListener('submit', function(e) {
  e.preventDefault();
  addCourse();
});

// Submit button event listener
var submitButton = document.querySelector('.submit-button');
submitButton.addEventListener('click', function() {
  courseForm.dispatchEvent(new Event('submit'));
});

// Cancel button event listener
var cancelButton = document.querySelector('.cancel-button');
cancelButton.addEventListener('click', function() {
  courseForm.reset();
});

// Function to add a course
function addCourse() {
  var courseCode = document.getElementById('courseCodeInput').value;
  var courseName = document.getElementById('courseNameInput').value;
  var semester = document.getElementById('semesterSelect').value;
  var deptName = document.getElementById('deptSelect').value;
  var credit = document.getElementById('creditInput').value;
  var students = document.getElementById('studentsInput').value;

  if (!courseCode || !courseName || !semester || !deptName || !credit || !students) {
    alert('Please fill in all fields');
    return;
  }

  var course = {
    courseCode: courseCode,
    courseName: courseName,
    semester: semester,
    deptName: deptName,
    credit: credit,
    students: students
  };

  var courses = getCoursesFromLocalStorage();
  courses.push(course);
  saveCoursesToLocalStorage(courses);

  renderCourseTable();
  courseForm.reset();
}

// Function to get courses from local storage
function getCoursesFromLocalStorage() {
  var coursesJson = localStorage.getItem('courses');
  return coursesJson ? JSON.parse(coursesJson) : [];
}

// Function to save courses to local storage
function saveCoursesToLocalStorage(courses) {
  localStorage.setItem('courses', JSON.stringify(courses));
}

// Function to render the course table
function renderCourseTable() {
  var courses = getCoursesFromLocalStorage();
  var tableBody = document.getElementById('courseTableBody');
  tableBody.innerHTML = '';

  for (var i = 0; i < courses.length; i++) {
    var course = courses[i];
    var row = document.createElement('tr');

    var courseCodeCell = document.createElement('td');
    courseCodeCell.textContent = course.courseCode;
    row.appendChild(courseCodeCell);

    var courseNameCell = document.createElement('td');
    courseNameCell.textContent = course.courseName;
    row.appendChild(courseNameCell);

    var semesterCell = document.createElement('td');
    semesterCell.textContent = course.semester;
    row.appendChild(semesterCell);

    var deptNameCell = document.createElement('td');
    deptNameCell.textContent = course.deptName;
    row.appendChild(deptNameCell);

    var creditCell = document.createElement('td');
    creditCell.textContent = course.credit;
    row.appendChild(creditCell);

    var studentsCell = document.createElement('td');
    studentsCell.textContent = course.students;
    row.appendChild(studentsCell);

    var actionsCell = document.createElement('td');
    var updateButton = document.createElement('button');
    updateButton.textContent = 'Update';
    updateButton.className="btn1"
    updateButton.addEventListener('click', function() {
      updateCourse(course.courseCode);
    });
    actionsCell.appendChild(updateButton);

    var deleteButton = document.createElement('button');
    deleteButton.textContent = 'Delete';
    deleteButton.className="btn2";
    deleteButton.addEventListener('click', function() {
      deleteCourse(course.courseCode);
    });
    actionsCell.appendChild(deleteButton);

    row.appendChild(actionsCell);

    tableBody.appendChild(row);
  }
}

// Function to update a course
function updateCourse(courseCode) {
  var courses = getCoursesFromLocalStorage();
  var course = courses.find(function(c) {
    return c.courseCode === courseCode;
  });

  if (!course) {
    return;
  }

  // Update the form fields with course data
  document.getElementById('courseCodeInput').value = course.courseCode;
  document.getElementById('courseNameInput').value = course.courseName;
  document.getElementById('semesterSelect').value = course.semester;
  document.getElementById('deptSelect').value = course.deptName;
  document.getElementById('creditInput').value = course.credit;
  document.getElementById('studentsInput').value = course.students;

  // Remove the course from the courses array
  courses = courses.filter(function(c) {
    return c.courseCode !== courseCode;
  });

  saveCoursesToLocalStorage(courses);
  renderCourseTable();
}

// Function to delete a course
function deleteCourse(courseCode) {
  var courses = getCoursesFromLocalStorage();
  courses = courses.filter(function(c) {
    return c.courseCode !== courseCode;
  });
  saveCoursesToLocalStorage(courses);
  renderCourseTable();
}

// Initial rendering of the course table
renderCourseTable();
