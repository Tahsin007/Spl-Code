<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "exam pilot";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $deptCode = $_POST["deptCode"];
    $deptName = $_POST["deptName"];
    $courses = $_POST["courses"];
    $semester = $_POST["semester"];
    $students = $_POST["students"];
    $credit = $_POST["credit"];

    $sql = "INSERT INTO department (dept_code, dept_name, totall_courses, totall_semester, totall_student, totall_credit)
            VALUES ('$deptCode', '$deptName', '$courses', '$semester', '$students', '$credit')";

    if ($conn->query($sql) === TRUE) {
        echo "Data inserted successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

}

$conn->close();
?>