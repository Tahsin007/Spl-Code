<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "exam pilot";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $deptName = $_POST["deptName"];
    $semester = $_POST["semester"];
    $courseCode = $_POST["courseCode"];
    $credit = $_POST["credit"];
    $courseName = $_POST["courseName"];
    $students = $_POST["students"];

    $sql = "INSERT INTO courses (department, semester, course_code, totall_credit, course_name, totall_students)
            VALUES ('$deptName', '$semester', '$courseCode', '$credit', '$courseName', '$students')";

    if ($conn->query($sql) === TRUE) {
        echo "Data inserted successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

}

$conn->close();
?>