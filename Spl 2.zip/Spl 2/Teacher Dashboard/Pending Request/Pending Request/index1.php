<?php
session_start();
if (!isset($_SESSION["teacher_name"])) {
  header("Location: http://localhost:3000/Login/login.php"); // Redirect to the login page if not logged in as a teacher
  exit();
}
// header("Content-Type: application/octet-stream");


$teacherName = $_SESSION["teacher_name"];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "exam pilot";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM sendrequest WHERE teacher_name = '$teacherName'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  // Output data for each request
  while ($row = $result->fetch_assoc()) {


    $requestId = $row["request_id"];
    $department = $row["department"];
    $semester = $row["semester"];
    $courseName = $row["course_name"];
    $courseCode = $row["course_code"];
    $syllabusFileName = $row["sqyllabus"];
    $questionPatternFileName = $row["question_pattern"];
    $deadline = $row["deadline"];

    // Directory where uploaded files are stored on your server
    $uploadDir = "/Exam Controller/Send Request/pdf/";
    // $uploadDir = "C:/Users/TANIM/Desktop/Upload Dir/ ";


    $syllabusFilePath = $uploadDir . $syllabusFileName;
    // "C:\Users\TANIM\Desktop\Upload Dir64f81efb84e5b_student_marks (7).pdf"
    // "C:\Users\TANIM\Desktop\Upload Dir64f8b1c8c48de_ezyzip.zip"

    // $syllabusFilePath= "C:\Users\TANIM\Desktop\Upload Dir64f8b23462860_Exam Controller.zip";
    $questionPatternFilePath = $uploadDir . $questionPatternFileName;


    echo "<h3>Syllabus: $syllabusFileName</h3>";
    echo "<button onclick='showFile(\"syllabusFrame\", \"$syllabusFilePath\")'>Show Syllabus</button>";
    echo "<iframe id='syllabusFrame' src='' width='100%' height='500px' style='display:none;'></iframe>";

    echo "<h3>Question Pattern: $questionPatternFileName</h3>";
    echo "<button onclick='showFile(\"questionPatternFrame\", \"$questionPatternFilePath\")'>Show Question Pattern</button>";
    echo "<iframe id='questionPatternFrame' src='' width='100%' height='500px' style='display:none;'></iframe>";

    // Output PDF files using <iframe>
    // echo "<h3>Syllabus: $syllabusFileName</h3>";
    // echo "<iframe src='$syllabusFilePath' width='100%' height='500px'></iframe>";

    // echo "<h3>Question Pattern: $questionPatternFileName</h3>";
    // echo "<iframe src='$questionPatternFilePath' width='100%' height='500px'></iframe>";

    // if (file_exists($syllabusFilePath)) {
    //   header('Content-Type: application/pdf');
    //   header('Content-Disposition: attachment; filename="'.$syllabusFileName.'"');
    //   readfile($syllabusFilePath);
    //   exit; // Exit after sending the file
    // } else {
    //   echo 'File not found: ' . $syllabusFilePath;
    // }
  }
} else {
  echo "No requests found for this teacher.";
}

$conn->close();
?>



<!DOCTYPE html>
<html>

<head>
  <title>Responsive Page</title>
  <link rel=" stylesheet" type="text/css" href="styles.css">
  <link rel="stylesheet" type="text/css" href="styles2.css">
  <link rel="stylesheet" type="text/css" href="/Exam Controller/Send Request/pdf/">


</head>

<body>
  <div class="container">
    <div class="menu">
      <div class="sidebar">
        <div class="sidebar-header">
          <h2><i class="fas fa-graduation-cap"></i> Teacher Panel</h2>
        </div>
        <ul class="nav">
          <li><a href="/Teacher Dashboard/Home/Home/index.php"><i class="fas fa-home"></i> Home</a></li>
          <li class="active"><a href="/Teacher Dashboard/Pending Request/Pending Request/index1.php"><i class="fas fa-user-clock"></i> Pending Request</a>
          </li>
          <!-- <li><a href=""><i class="fas fa-question-circle"></i> Send Question</a> -->
          </li>
          <li><a href="/Teacher Dashboard/Enter Marks/Enter Marks/index.php"><i class="fas fa-edit"></i> Enter Marks</a></li>
          <li><a href="/Teacher Dashboard/Mark Attendance/Mark Attendance//index.php"><i class="fas fa-clipboard-list"></i> Mark
              Attendance</a></li>
          <li><a href="/Teacher Dashboard/Attendance Report/Attendance Report/index.php"><i class="fas fa-file-alt"></i> Attendance
              Report</a></li>
          <li><a href="/Teacher Dashboard/Assigned Subject/Assigned Subjects/index.php"><i class="fas fa-book"></i> Assigned Subjects</a>
          </li>
          <li><a href="/Teacher Dashboard/Marksheet Report/Marksheet Report/index.php"><i class="fas fa-file-signature"></i> Marksheet
              Report</a></li>
          <!-- <li><a href="/Teacher Dashboard/Notification/notification.php"><i class="fas fa-bell"></i> Notifications</a></li> -->
          <li><a href="/Teacher Dashboard/Update Profile/Update Profile/index.php"><i class="fas fa-user"></i> Update Profile</a></li>
          <li><a href="/Teacher Dashboard/Log Out/logout.php"><i class="fas fa-sign-out"></i> Log Out</a></li>
        </ul>
      </div>
      <div class="content">
        <!-- <a href="64f8f3b405a2d_student_marks.pdf" target="_blank">Click Question</a> -->
        <div class="section-title">Pending Request</div>
        <!-- <embed src="C:\Users\TANIM\Desktop\Upload Dir\ <?php echo $syllabusFilePath . ".pdf"; ?>" type="application/pdf" width="700" height="700> -->
        <div class="mainCard">
          <div class="title">
            <h3>You have received a request to set this paper.</h3>
          </div>
          <div class="para">
            <p>
              Subject Code: <?php echo "$courseCode"; ?> <br> Course Name: <?php echo "$courseName" ?> <br> Semester: <?php echo "$semester" ?><br> Dept Name: <?php echo "$department" ?> <br> Sent From: Exam Controller <br> Question: <?php echo "$syllabusFilePath" ?></p>
          </div>
          <!-- <div class="btn">
            <button class="btn1">Accept</button>
            <button class="btn2">Reject</button>
          </div> -->
        </div>

        <!-- <div class="card-row">
        <div class="card">
          <div class="card-content">
            <div class="card-icon">
              <img src="./images/students.png" alt="Icon 1">
            </div>
            <h2>Students Assigned</h2>
            <h3>135</h3>
            
          </div>
        </div>
        <div class="card">
          <div class="card-content">
            <div class="card-icon">
              <img src="./images/courses.png" alt="Icon 2">
            </div>
            <h2>Courses Assigned</h2>
            <h3>25</h3>
            
          </div>
        </div>
      </div> -->
        <!-- <div class="card-row">
        <div class="card">
          <div class="card-content">
            <div class="card-icon">
              <img src="./images/faculties.png" alt="Icon 3">
            </div>
            <h2>Courses Assigned</h2>
            <h3>3</h3>
            
          </div>
        </div>
        <div class="card">
          <div class="card-content">
            <div class="card-icon">
              <img src="./images/Departments.png" alt="Icon 4">
            </div>
            <h2>Departments</h2>
            <h3>1</h3>
            
          </div>
        </div>
      </div> -->
      </div>
    </div>
    <script>
      function showFile(iframeId, filePath) {
        const iframe = document.getElementById(iframeId);
        iframe.src = filePath;
        iframe.style.display = 'block';
      }
    </script>
    <!-- <script src="script.js"></script> -->
</body>

</html>