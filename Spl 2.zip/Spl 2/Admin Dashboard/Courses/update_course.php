<?php
// Check if the student_id query parameter is set
if (isset($_GET["course_code"])) {
    // Database configuration
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "exam pilot"; 

    // Create a database connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get the student ID from the URL
    $course_code = $_GET["course_code"];

    // Retrieve the student's data based on the student ID
    $sql = "SELECT * FROM courses WHERE course_code = '$course_code' ";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Fetch the student's data
        $row = $result->fetch_assoc();
        $course_code = $row["course_code"];
        $course_name = $row["course_name"];
        $department = $row["department"];
        $semester=$row["semester"];
        $totall_credit=$row["totall_credit"];
        $totall_students=$row["totall_students"];

        // Add other fields as needed

        // Close the database connection
        $conn->close();
    } else {
        echo "Student not found.";
        exit; // Exit the script if the student is not found
    }
} else {
    echo "Student ID not provided.";
    exit; // Exit the script if no student ID is provided
}
?>


<!DOCTYPE html>
<html>
<head>
  <title>Edit Course Details</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="container">
    <div class="content">
      <div class="title-section">
        <h1>Edit Course Details</h1>
      </div>
      <div class="form-section">
        <form method="post" action="changeCourse.php">
          <!-- <input type="text" name="student_id" value="<?php echo $course_code; ?>"> -->
          <div class="form-field">
            <label for="studentId">Course Code:</label>
            <input type="text" name="dept_code" value="<?php echo $course_code; ?>">
          </div>
          <div class="form-field">
            <label for="studentName">Course Name:</label>
            <input type="text" name="dept_name" value="<?php echo $course_name; ?>" required>
          </div>
          <div class="form-field">
            <label for="emailId">Department Name:</label>
            <input type="text" name="courses" value="<?php echo $department; ?>" >
          </div>
          <div class="form-field">
            <label for="contact">Semester:</label>
            <input type="text" name="semester" value="<?php echo $semester; ?>" >
          </div>
          <div class="form-field">
            <label for="deptName">Totall Credit:</label>
            <input type="text" name="student" value="<?php echo $totall_credit; ?>" >
          </div>
          <div class="form-field">
            <label for="password">Totall Students :</label>
            <input type="text" name="credit" value="<?php echo $totall_students; ?>" >
          </div>
          <!-- Add other form fields as needed -->
          <div class="form-actions">
            <button type="submit">Update</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</body>
</html>
