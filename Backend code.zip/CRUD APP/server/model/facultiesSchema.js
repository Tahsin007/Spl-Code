const mongoose = require('mongoose');

var facultyschema = new mongoose.Schema({
    teacherid:String,
    teachername:String,
    emailid:String,
    contact:String,
    deptname:String,
    password:String
})

const teacher = mongoose.model('teacher',facultyschema);
module.exports = teacher;