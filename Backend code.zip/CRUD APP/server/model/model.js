const mongoose = require('mongoose');

var schema = new mongoose.Schema({
    studentid:String,
    studentname:String,
    emailid:String,
    contact:String,
    deptname:String,
    password:String
})

const student = mongoose.model('student',schema);
module.exports = student;