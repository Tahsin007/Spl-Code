<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "exam pilot";

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $teacherId = $_POST["teacher_id"];
    $teacherName = $_POST["teacher_name"];
    $emailId = $_POST["email_id"];
    $contact = $_POST["contact"];
    $deptName = $_POST["deptName"];
    $password =$_POST["password"];



    // Update the student data in the database
    $sql = "UPDATE faculties SET password='$password', dept_name='$deptName', contact='$contact', teacher_name='$teacherName', email_id='$emailId', teacher_id= '$teacherId' WHERE teacher_id= '$teacherId' ";

    if ($conn->query($sql) === TRUE) {
        echo "Teacher data updated successfully.";
    } else {
        echo "Error updating teacher data: " . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>