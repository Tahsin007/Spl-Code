<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "exam pilot";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $studentId = $_POST["studentId"];
    $studentName = $_POST["studentName"];
    $emailId = $_POST["emailId"];
    $contact = $_POST["contact"];
    $deptName = $_POST["deptName"];
    $password = $_POST["password"];
    $semester = $_POST["semester"];

    $sql = "INSERT INTO students (student_id, student_name, email_id, contact, dept_name, password,semester)
            VALUES ('$studentId', '$studentName', '$emailId', '$contact', '$deptName', '$password','$semester')";

    if ($conn->query($sql) === TRUE) {
        echo "Data inserted successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();
?>
