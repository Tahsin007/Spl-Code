const express = require('express')
const route = express.Router();
var Student = require('../model/model');
var teacher = require('../model/facultiesSchema');

//Everything about Students

route.get('/students',(req,res)=>{
    res.render('studentsAdd');
})

route.post('/addStudents',express.json(), async (req,res)=>{
    try{
      console.log("Received Request Body", req.body);

        const addStudent = new Student({
            studentid:req.body.studentId,
            studentname:req.body.studentName,
            emailid:req.body.emailId,
            contact:req.body.contact,
            deptname:req.body.deptName,
            password:req.body.password
        })
        console.log("Adding student:", addStudent);

        const savedStudent = await addStudent.save();
        console.log("Student saved:", savedStudent);

        res.status(201).send("Student added successfully!");

    }catch(e){
        res.status(400).send("Data can not be inserted at this time");
    }
});

route.get('/studentsShow', async (req, res) => {
    try {
        const students = await Student.find(); // Retrieve all Teacher from the database
        res.json(students);
    } catch (error) {
        console.error('Error fetching students:', error);
        res.status(500).send('Error fetching students');
    }
});

//Everything about faculties

route.get('/faculties',(req,res)=>{
    res.render('FacultiesAdd');
})

route.post('/addFaculties',express.json(), async (req,res)=>{
    try{
      console.log("Received Request Body", req.body);
      
        const addFaculty = new teacher({
            teacherid:req.body.teacherId,
            teachername:req.body.teacherName,
            emailid:req.body.emailId,
            contact:req.body.contact,
            deptname:req.body.deptName,
            password:req.body.password
        })
        
        console.log("Adding Faculties:", addFaculty);

        const savedFaculty = await addFaculty.save();
        console.log("Faculty saved:", savedFaculty);

        res.status(201).send("Faculty added successfully!");

    }catch(e){
        res.status(400).send("Data can not be inserted at this time");
    }
});

route.get('/facultiesShow', async (req, res) => {
    try {
        const Teacher = await teacher.find(); // Retrieve all Teacher from the database
        res.json(Teacher);
    } catch (error) {
        console.error('Error fetching students:', error);
        res.status(500).send('Error fetching students');
    }
});

//everything about Courses
route.get('/courses',(req,res)=>{
    res.render('coursesAdd');
})


module.exports=route;