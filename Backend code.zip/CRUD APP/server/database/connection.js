// db.js
const mongoose = require('mongoose');

const dbURI = 'mongodb+srv://Tahsin:tanimpes2019@cluster0.0qph8z3.mongodb.net/?retryWrites=true&w=majority';
const options = {
  useNewUrlParser: true,
  useUnifiedTopology: true,
};

const connectDB = async () => {
  try {
    await mongoose.connect(dbURI, options);
    console.log('Connected to the database');
  } catch (err) {
    console.error('Error connecting to the database:', err);
  }
};

module.exports = connectDB;
