<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "exam pilot";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $deptCode = $_POST["deptCode"];
    $deptName = $_POST["deptName"];
    $courses = $_POST["courses"];
    $semester = $_POST["semester"];
    $students = $_POST["students"];
    $credit = $_POST["credit"];

    $sql = "INSERT INTO department (dept_code, dept_name, totall_courses, totall_semester, totall_student, totall_credit)
            VALUES ('$deptCode', '$deptName', '$courses', '$semester', '$students', '$credit')";

    $conn->query($sql);
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Department</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <div class="popup" id="popup">
        <div class="popup-content">
            <span class="close" id="close">&times;</span>
            <h2>Course Inserted Successfully</h2>
            <p>Your Course data has been inserted into the database.</p>
        </div>
    </div>
    <script>
        var popup = document.getElementById("popup");
        var close = document.getElementById("close");

        function showPopup() {
            popup.classList.add("show");
        }

        close.addEventListener("click", function() {
            popup.classList.remove("show");
        });

        <?php
        if (isset($_POST["deptName"]) ) {
            echo "showPopup();";
        }
        ?>
    </script>

</body>

</html>