<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "exam pilot";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET["student_id"])) {
    $studentId = $_GET["student_id"];

    $sql = "DELETE FROM students WHERE student_id = '$studentId'";

    if ($conn->query($sql) === TRUE) {
        echo "Student record deleted successfully.";
    } else {
        echo "Error deleting student record: " . $conn->error;
    }
}

$conn->close();
?>
