const mongoose = require('mongoose');

var coursesSchema = new mongoose.Schema({
    teacherid:String,
    teachername:String,
    emailid:String,
    contact:String,
    deptname:String,
    password:String
})

const courses = mongoose.model('courses',coursesSchema);
module.exports = courses;