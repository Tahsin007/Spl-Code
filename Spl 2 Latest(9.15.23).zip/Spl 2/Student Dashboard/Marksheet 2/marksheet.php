<?php
session_start();
if (!isset($_SESSION["student_id"])) {
    echo "student id is not setup";
    header("Location: http://localhost:3000/Login/login.php"); // Redirect to the login page if not logged in
    exit();
}

$student_id = $_SESSION["student_id"];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "exam pilot";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT * FROM students WHERE student_id = '$student_id' ";
$result = $conn->query($sql);

if (isset($result) && $result->num_rows == 1) {
    $row = $result->fetch_assoc();

    $id = $row["student_id"];
    $name = $row["student_name"];
    $email = $row["email_id"];
    $contact = $row["contact"];
    $dept_name = $row["dept_name"];
    $semester = $row["semester"];
    $password = $row["password"];
} else {
    echo "Records not found";
    header("Location: http://localhost:3000/Login/login.php");

    exit();
}
// $sql2 = "SELECT * from student_marks WHERE student_id='$student_id";

$sql2 = "SELECT sm.course_code, c.course_name, c.totall_credit, sm.totall_marks, sm.grade  
        FROM student_marks as sm 
        INNER JOIN courses as c ON sm.course_code = c.course_code
        WHERE sm.student_id = '$student_id' ";

$result2 = $conn->query($sql2);


// $sql2 = "SELECT sm.student_id, c.course_code, c.course_title, c.course_credit, sm.total_marks, sm.grade
//         FROM student_marks sm
//         INNER JOIN student s ON sm.student_id = s.student_id
//         INNER JOIN courses c ON sm.course_code = c.course_code
//         WHERE sm.student_id = '$student_id' ";

// $result2 = $conn->query($sql2);

// if ($result2->num_rows > 0) {

//     while ($row = $result2->fetch_assoc()) {
//         echo "<tr>
//                 <td>" . $row["student_id"] . "</td>
//                 <td>" . $row["course_code"] . "</td>
//                 <td>" . $row["course_title"] . "</td>
//                 <td>" . $row["course_credit"] . "</td>
//                 <td>" . $row["total_marks"] . "</td>
//                 <td>" . $row["grade"] . "</td>
//               </tr>";
//     }

//     echo "</table>";
// } else {
//     echo "No records found";
// }

// $conn->close();
?>

<!DOCTYPE html>
<html>

<head>
    <title>Student Panel</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
    <link rel="stylesheet" type="text/css" href="styles2.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

</head>

<body>
    <!-- Left Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h2><i class="fas fa-graduation-cap"></i> Student Panel</h2>
        </div>
        <ul class="nav">
            <li><a href="../home/home.html"><i class="fas fa-home"></i> Home</a></li>
            <li><a href="../courses/courses.html"><i class="fas fa-book"></i> Courses</a></li>
            <li><a href="../facalties/faculties.html"><i class="fas fa-users"></i> Faculties</a></li>
            <li class="active"><a href="#"><i class="fas fa-file-text"></i> Marksheet</a></li>
            <li><a href="../Attendance Report/attendanceReport.html"><i class="fas fa-list-alt"></i> Attendance
                    Report</a></li>
            <li><a href="../Update Profile/updateProfile.html"><i class="fas fa-user"></i> Update Profile</a></li>
            <li><a href="../Notification/notification.html"><i class="fas fa-bell"></i> Notification</a></li>
            <li><a href="../Log Out/logout.html"><i class="fas fa-sign-out"></i> Log Out</a></li>
        </ul>
    </div>

    <!-- Main Content -->
    <div class="content">
        <div class="header">

            <div class="user-info">
                <div class="user-details">
                    <h1 style="color: rgb(250, 250, 250);">Marksheet</h1>

                </div>

            </div>
            <button class="download-button">Download</button>
        </div>

        <div class="body2">
            <div class="StudentInfo">

                <div class="info-column">
                    <p><strong>Student ID: <?php echo $id; ?></strong> <span id="student-id"></span></p>

                    <p><strong>Department: <?php echo $dept_name; ?></strong> <span id="department"></span></p>

                    <p><strong>Email: <?php echo $email; ?> </strong> <span id="dob"></span></p>

                </div>
                <div class="info-column">

                    <p><strong>Student Name: <?php echo $name; ?></strong> <span id="student-name"></span></p>

                    <p><strong>Semester/Year: <?php echo $semester; ?></strong> <span id="semester"></span></p>

                    <p><strong>Contact : <?php echo $contact; ?></strong> <span id="gender"></span></p>
                </div>
            </div>
            <div class="table-section">
                <table id="courseTable">
                    <thead>
                        <tr>
                            <th>Course Code</th>
                            <th>Course Tittle</th>
                            <th>Credits</th>
                            <th>Totall Marks</th>
                            <th>Grade</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        if (isset($result2) && $result2->num_rows > 0) {
                            while ($row = $result2->fetch_assoc()) {
                                echo "<tr>";
                                echo "<td style='text-align: center;'>" . $row["course_code"] . "</td>";
                                echo "<td style='text-align: center;'>" . $row["course_name"] . "</td>";
                                echo "<td style='text-align: center;'>" . $row["totall_credit"] . "</td>";
                                echo "<td style='text-align: center;'>" . $row["totall_marks"] . "</td>";
                                echo "<td style='text-align: center;'>" . $row["grade"] . "</td>";
                                // $courseCode = $row["course_code"];
                                // echo "<td style='text-align: center;'><a href='update_course.php?course_code=$courseCode'>Edit</a> | <a href='deleter_course.php?course_code=$courseCode' onclick='return confirm(\"Are you sure you want to delete this Course record?\")'>Delete</a></td>";

                                echo "</tr>";
                            }
                        } else {
                            echo "<tr><td colspan='7'>No records found</td></tr>";
                        }
                        $conn->close();

                        ?>
                    </tbody>
                </table>
            </div>

            <!-- <button class="download-button">Download</button> -->
        </div>
    </div>

    <!-- <script src="script.js"></script> -->
</body>

</html>