<?php
session_start();
if (!isset($_SESSION["admin_id"])) {
  header("Location: http://localhost:3000/Login/login.php"); // Redirect to the login page if not logged in
  exit();
}

// Retrieve admin details from your database based on the admin_id stored in the session
$admin_id = $_SESSION["admin_id"];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "exam pilot";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql = "SELECT * FROM admin WHERE admin_id = $admin_id";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
  $admin_details = $result->fetch_assoc();

  $admin_name = $admin_details["username"];
  $admin_email = $admin_details["admin_email"];
  $admin_password = $admin_details["password"];
} else {
  header("Location: http://localhost:3000/Login/login.php");
  exit();
}

$sql_students = "SELECT COUNT(*) as student_count FROM students";
$sql_departments = "SELECT COUNT(*) as department_count FROM department";
$sql_courses = "SELECT COUNT(*) as course_count FROM courses";
$sql_faculties = "SELECT COUNT(*) as faculty_count FROM faculties";

// Execute the queries
$result_students = $conn->query($sql_students);
$result_departments = $conn->query($sql_departments);
$result_courses = $conn->query($sql_courses);
$result_faculties = $conn->query($sql_faculties);

// Fetch the counts from the query results
$row_students = $result_students->fetch_assoc();
$row_departments = $result_departments->fetch_assoc();
$row_courses = $result_courses->fetch_assoc();
$row_faculties = $result_faculties->fetch_assoc();

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html>

<head>
  <title>Admin Homepage</title>
  <link rel="stylesheet" type="text/css" href="styles.css">
</head>

<body>
  <div class="container">
    <div class="menu">
      <div class="menu-icon">
        <span><img src="./images/mobile menu.png" alt=""></span>
        <span></span>
        <span></span>
      </div>
      <ul class="menu-items">
        <li class="admin">
          <h3>Admin Panel</h3>
        </li>
        <li class="admin1"><a href="#"><?php echo $admin_name; ?> </a></li>
        <li><a href="#"><i class="fas fa-home"></i> Home</a></li>
        <li><a href="#"><i class="fas fa-user"></i> Update Profile</a></li>
        <li><a href="#"><i class="fa-solid fa-user"></i> Students</a></li>
        <li><a href="#"><i class="fa-solid fa-chalkboard-user"></i> Faculties</a></li>
        <li><a href="#"><i class="fa-solid fa-graduation-cap"></i> Courses</a></li>
        <li><a href="#"><i class="fa-solid fa-user-graduate"></i>Department</a></li>
        <li><a href="#"><i class="fa-solid fa-magnifying-glass"></i> Search</a></li>
        <!-- <li><a href="#"><i class="fa-sharp fa-solid fa-bell"></i> Notification</a></li> -->
        <li><a href="/Admin Dashboard//logout.php"><i class="fa-solid fa-right-from-bracket"></i> Log Out</a></li>
      </ul>
    </div>
    <div class="details">
      <h3>Welcome, <?php echo $admin_name; ?> </h3>
      <h3>Email :, <?php echo $admin_email; ?> </h3>
    </div>
    <div class="content">
      <div class="card-row">
        <div class="card">
          <div class="card-content">
            <div class="card-icon">
              <img src="./images/students.png" alt="Icon 1">
            </div>
            <h2>Students</h2>
            <h3> <?php echo $row_students['student_count']; ?></h3>

          </div>
        </div>
        <div class="card">
          <div class="card-content">
            <div class="card-icon">
              <img src="./images/courses.png" alt="Icon 2">
            </div>
            <h2>Courses</h2>
            <h3><?php echo $row_courses['course_count']; ?></h3>

          </div>
        </div>
      </div>
      <div class="card-row">
        <div class="card">
          <div class="card-content">
            <div class="card-icon">
              <img src="./images/faculties.png" alt="Icon 3">
            </div>
            <h2>Faculties</h2>
            <h3><?php echo $row_faculties['faculty_count']; ?></h3>

          </div>
        </div>
        <div class="card">
          <div class="card-content">
            <div class="card-icon">
              <img src="./images/Departments.png" alt="Icon 4">
            </div>
            <h2>Departments</h2>
            <h3><?php echo $row_departments['department_count']; ?></h3>

          </div>
        </div>
      </div>
    </div>
  </div>
  <script src="script.js"></script>
</body>

</html>