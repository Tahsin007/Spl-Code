 <?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "exam pilot";

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve all student records from the database
$sql = "SELECT * FROM department";
$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html>
<head>
  <title>Departmentst</title>
  <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
  <div class="container">
    <div class="menu">
      <ul>
        <li><a href="#"><i class="fas fa-home"></i> Home</a></li>
        <li><a href="#"><i class="fas fa-user"></i> Update Profile</a></li>
        <li><a href="#"><i class="fa-solid fa-user"></i> Students</a></li>
        <li><a href="#"><i class="fa-solid fa-chalkboard-user"></i> Faculties</a></li>
        <li><a href="#"><i class="fa-solid fa-graduation-cap"></i> Courses</a></li>
        <li><a href="#"><i class="fa-solid fa-user-graduate"></i>Department</a></li>
        <li><a href="#"><i class="fa-solid fa-magnifying-glass"></i> Search</a></li>
        <li><a href="#"><i class="fa-sharp fa-solid fa-bell"></i> Notification</a></li>
        <li><a href="#"><i class="fa-solid fa-right-from-bracket"></i> Log Out</a></li>
      </ul>
    </div>
    <div class="content">
      <div class="title-section">
        <h1>Departments</h1>
      </div>
      <div class="form-section">
        <form method="post" action="db.php" id="myForm">
          <div class="form-row">
            <div class="form-field">
              <label for="studentId">Dept Code:</label>
              <input type="text" name="deptCode" required>
            </div>
            <div class="form-field">
              <label for="studentName">Dept Name:</label>
              <input type="text" name="deptName" required>
            </div>
            <div class="form-field">
              <label for="totallCourses">Totall Courses:</label>
              <input type="number" name="courses" required>
            </div>
          </div>
          <div class="form-row">
            <div class="form-field">
              <label for="contact">Totall Semester:</label>
              <input type="number" name="semester" required>
            </div>
            <div class="form-field">
              <label for="deptName">Totall Students:</label>
              <input type="number" name="students" required>
            </div>
            <div class="form-field">
              <label for="password">Totall Credit:</label>
              <input type="number" name="credit" required>
            </div>
          </div>
          <div class="form-actions">
            <input type="submit" value="Submit" class="btn1">
            <!-- <button type="submit" class="btn1">Submit</button> -->
            <button type="button" onclick="cancelForm()" class="btn2">Cancel</button>
          </div>
        </form>
      </div>
      <div class="table-section">
        <table id="studentsTable">
          <thead>
            <tr>
              <th>Dept Code</th>
              <th>Dept Name</th>
              <th>Totall Courses</th>
              <th>Totall Semester</th>
              <th>Totall Students</th>
              <th>Totall Credit</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td style='text-align: center;'>" . $row["dept_code"] . "</td>";
                    echo "<td style='text-align: center;'>" . $row["dept_name"] . "</td>";
                    echo "<td style='text-align: center;'>" . $row["totall_courses"] . "</td>";
                    echo "<td style='text-align: center;'>" . $row["totall_semester"] . "</td>";
                    echo "<td style='text-align: center;'>" . $row["totall_student"] . "</td>";
                    echo "<td style='text-align: center;'>" . $row["totall_credit"] . "</td>";
                    $deptCode = $row["dept_code"];
                    echo "<td style='text-align: center;'><a href='update_dept.php?dept_code=$deptCode'>Edit</a> | <a href='delete_dept.php?dept_code=$deptCode' onclick='return confirm(\"Are you sure you want to delete this Course record?\")'>Delete</a></td>";

                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='7'>No records found</td></tr>";
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <!-- <script src="script.js"></script> -->
</body>
</html>
