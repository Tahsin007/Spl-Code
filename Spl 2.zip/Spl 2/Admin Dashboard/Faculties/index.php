<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "exam pilot";

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
  // Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $teacherId = $_POST["teacherId"];
    $teacherName = $_POST["teacherName"];
    $emailId = $_POST["emailId"];
    $contact = $_POST["contact"];
    $deptName = $_POST["deptName"];
    $password = $_POST["password"];

    // Prepare and execute an SQL INSERT statement
    $sql = "INSERT INTO faculties (teacher_id, teacher_name, email_id, contact, dept_name, password)
            VALUES ('$teacherId', '$teacherName', '$emailId', '$contact', '$deptName', '$password')";

    if ($conn->query($sql) === TRUE) {
        echo "Data inserted successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $sql = "SELECT * FROM faculties";
    $result = $conn->query($sql);
}

// Close the database connection
$conn->close();

?>


<!DOCTYPE html>
<html>
<head>
  <title>Student Management</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <div class="container">
    <div class="menu">
      <ul>
        <li><a href="#"><i class="fas fa-home"></i> Home</a></li>
        <li><a href="#"><i class="fas fa-user"></i> Update Profile</a></li>
        <li><a href="#"><i class="fa-solid fa-user"></i> Students</a></li>
        <li><a href="#"><i class="fa-solid fa-chalkboard-user"></i> Faculties</a></li>
        <li><a href="#"><i class="fa-solid fa-graduation-cap"></i> Courses</a></li>
        <li><a href="#"><i class="fa-solid fa-user-graduate"></i>Department</a></li>
        <li><a href="#"><i class="fa-solid fa-magnifying-glass"></i> Search</a></li>
        <li><a href="#"><i class="fa-sharp fa-solid fa-bell"></i> Notification</a></li>
        <li><a href="#"><i class="fa-solid fa-right-from-bracket"></i> Log Out</a></li>
      </ul>
    </div>
    <div class="content">
      <div class="title-section">
        <h1>Faculties</h1>
      </div>
      <div class="form-section">
        <form action="index.php" method="post" id="myForm">
          <div class="form-row">
            <div class="form-field">
              <label for="teacherId">Teacher ID:</label>
              <input type="text" name="teacherId" required>
            </div>
            <div class="form-field">
              <label for="studentName">Teacher Name:</label>
              <input type="text" name="teacherName" required>
            </div>
            <div class="form-field">
              <label for="emailId">Email ID:</label>
              <input type="text" name="emailId" required>
            </div>
          </div>
          <div class="form-row">
            <div class="form-field">
              <label for="contact">Contact:</label>
              <input type="tel" name="contact" required>
            </div>
            <div class="form-field">
              <label for="deptName">Dept. Name:</label>
              <input type="text" name="deptName" required>
            </div>
            <div class="form-field">
              <label for="password">Password:</label>
              <input type="password" name="password" required>
            </div>
          </div>
          <div class="form-actions">
            <input type="submit" class="btn1" value="Submit">
            <!-- <button type="submit" class="btn1">Submit</button> -->
            <button type="button" onclick="cancelForm()" class="btn2">Cancel</button>
          </div>
        </form>
      </div>
      <div class="table-section">
        <table id="studentsTable">
          <thead>
            <tr>
              <th>Student ID</th>
              <th>Student Name</th>
              <th>Email ID</th>
              <th>Contact</th>
              <th>Dept. Name</th>
              <th>Password</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php
            // Loop through the retrieved records and display them in the table
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["teacher_id"] . "</td>";
                    echo "<td>" . $row["teacher_name"] . "</td>";
                    echo "<td>" . $row["email_id"] . "</td>";
                    echo "<td>" . $row["contact"] . "</td>";
                    echo "<td>" . $row["dept_name"] . "</td>";
                    echo "<td>" . $row["password"] . "</td>";
                    $teacherId = $row["teacher_id"];
                    echo "<td><a href='update_teacher.php?teacher_id=$teacherId'>Edit</a> | <a href='delete_teacher.php?teacher_id=$teacherId' onclick='return confirm(\"Are you sure you want to delete this student record?\")'>Delete</a></td>";

                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='7'>No records found</td></tr>";
            }
            ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
  <!-- <script src="script.js"></script> -->
</body>
</html>
