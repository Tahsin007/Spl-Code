<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "exam pilot";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET["teacher_id"])) {
    $teacherId = $_GET["teacher_id"];

    $sql = "DELETE FROM faculties WHERE teacher_id = '$teacherId'";

    if ($conn->query($sql) === TRUE) {
        echo "Teacher record deleted successfully.";
    } else {
        echo "Error deleting teacher record: " . $conn->error;
    }
}

$conn->close();
?>
